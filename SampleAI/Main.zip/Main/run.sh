
cd `dirname $0`
javac Main.java
java Main
